<?php
	class FeedBack{
		private $id=null;
		private $prochainSujet=null;
        private $rcmnd=null;
		private $satisfaction=1;
        private $suggestions=null;
		private $email=null;
        private $dateAjout=null;

		function __construct($prochainSujet,$rcmnd,$satisfaction,$suggestions,$email,$dateAjout){
            $this->prochainSujet=$prochainSujet;
            $this->rcmnd=$rcmnd;
            $this->satisfaction=$satisfaction;
            $this->suggestions=$suggestions;
            $$this->email=$email;
            $this->dateAjout=$dateAjout;

		}

		public function getId()
		{
				return $this->id;
		}

		public function getProchainSujet()
		{
				return $this->prochainSujet;
		}

        public function getRcmnd()
        {
                return $this->rcmnd;
        }

		public function getSatisfaction()
		{
				return $this->satisfaction;
		}

        public function getSuggestions()
        {
                return $this->suggestions;
        }

		public function getEmail()
		{
				return $this->email;
		}

        public function getDateAjout()
        {
                return $this->dateAjout;
        }

    }

	
	
?>
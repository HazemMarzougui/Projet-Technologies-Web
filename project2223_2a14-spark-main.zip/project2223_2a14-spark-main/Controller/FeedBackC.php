<?php
	include_once dirname(__FILE__).'/../Config.php';
	include_once dirname(__FILE__).'/../Model/FeedBack.php';

	require __DIR__.'../../twilio-php-main/src/Twilio/autoload.php';
	use Twilio\Rest\Client;


	$FeedBackC=new FeedBackC();
	class FeedBackC {
        function getAllFeedBack(){
			$sql="SELECT * FROM feedBack";
			$db = config::getConnexion();
			try{
				$feedB = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
				return $feedB;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}

		function deleteFeedBack(int $id){
			$sql="DELETE from feedback WHERE id=".$id;
			$db = config::getConnexion();
			try{
				$feedB = $db->query($sql);
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}

		function updateEtatFeedBack(int $id,int $nbr){
			$sql="UPDATE feedback SET EtatFeedBack =$nbr WHERE id=".$id;
			$db = config::getConnexion();
			try{
				$feedB = $db->query($sql);
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}

		function insertFeedBack(String $nextSujet,int $rcmntd,int $satisf,String $sugg,String $email){
			$date = date('y-m-d h:i:s');
			$sql="INSERT INTO feedback VALUES (NULL,'$nextSujet', $rcmntd, $satisf, '$sugg',  '$email','$date',0);";
			$db = config::getConnexion();
			try{
				$feedB = $db->query($sql);
				$sid = 'AC8204a663565ef1865d71539fc01f430f';
				$token = '10ba6f57df7d3e08b69662fb22fb020d';
				$client = new Client($sid, $token);
				$message=$client->messages->create(
					'+21692598384',
					[
						'from' => '+19737919103',
						'body' => "Nouvelle FeedBack à été ajouté!"
						]
					);
				return $feedB;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}


        function getStatFeedBackWeek(){
            $sql="SELECT COUNT(id) as nbr ,dateAjout as dateAjout FROM feedback f WHERE dateAjout BETWEEN DATE( NOW() )-7 and DATE( NOW() ) GROUP BY dateAjout";
			$db = config::getConnexion();
			try{
				$feedB = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
				return  $feedB;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
        }

        function getStatprochainSujet(){
            $sql="SELECT COUNT(id) as nbr ,prochainSujet as prochainSujet FROM feedback f WHERE dateAjout BETWEEN DATE( NOW() )-7 and DATE( NOW() ) GROUP BY prochainSujet order by COUNT(id) desc limit 5";
			$db = config::getConnexion();
			try{
				$feedB = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
				return  $feedB;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
        }

        function getStatSatisfaction(){
            $sql="SELECT COUNT(id) as nbr ,satisfaction as satisfaction FROM feedback f WHERE dateAjout BETWEEN DATE( NOW() )-7 and DATE( NOW() ) GROUP BY satisfaction ORDER by satisfaction asc";
			$db = config::getConnexion();
			try{
				$feedB = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
				return  $feedB;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
        }

		function getSuggestion(){
            $sql="SELECT COUNT(id) as nbr ,rcmnd as rcmnd FROM feedback f WHERE dateAjout BETWEEN DATE( NOW() )-7 and DATE( NOW() ) GROUP BY rcmnd";
			$db = config::getConnexion();
			try{
				$feedB = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
				return  $feedB;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
        }

    }
           
?>
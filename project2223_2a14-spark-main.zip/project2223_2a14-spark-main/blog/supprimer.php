<?php
session_start();
if(!isset($_SESSION['login'])) {
header('Location: blogsender_recever.php');
  exit;
}
if(isset($_POST['id']))
{
  include('connecting.php');
  $sql = 'DELETE FROM news WHERE id='.$_POST['id'];
  $req = mysql_query($sql) or die(mysql_error()); 
  $req40 = 'DELETE FROM blogsender_recever WHERE iduser='.$_GET['id'];
  $res40 = mysql_query($req40);
  mysql_close();
  $fichier = "upload/";
  $filename = $_POST['id'];
  $point = ".";
  $total = $fichier.$filename.$point;

  if (file_exists($total.$jpg))
    {
      $suppr = unlink($total.$jpg);
    } 
  elseif (file_exists($total.$jpeg)) 
    {
      $suppr = unlink($total.$jpeg);
    } 
  elseif (file_exists($total.$bmp)) 
    {
     $suppr = unlink($total.$bmp);
    } 
  elseif (file_exists($total.$gif)) 
    {
      $suppr = unlink($total.$gif);
    }
  else
    {
      $action = "0";
    }
  if($req == true && $req40 == true && $suppr == true) 
    {
      header('Location: dd.php');
      exit;
    }
  elseif ($req == true && $req40 == true && $action == 0)
    {
      header('Location: dd.php');
      exit;
    }
  else
    {
?>

<?php
require "dd.php";

try 
{
/*$query= $pdo->prepare(
   ' INSERT INTO personne(nom, prenom, age) VALUES (:nom,:prenom,:age)'
);
$query->execute([

    'nom'=>'ben amen',
    'prenom' =>'amine',
    'age'=>22
    query= $pdo->prepare("UPDATE `personne` SET `nom`=:nom,`prenom`=:prenom,`age`=:age WHERE age=:age");
    $query->execute([
        'nom'=>'ben amen2',
    'prenom' =>'amine1',
    'age'=>222*/

    query= $pdo->prepare("DELETE FROM `personne` WHERE age:=age");
    $query->execute([

    'age'=>222

]);




}catch(PDOException $e)
{$e ->getMessage();}


?>
<?php
print_r($GLOBALS);

$id_sender=88;//Session ou cookies
$iduser = $_POST['iduser'];//tableau des idrecever

$messagetosend = $_POST['messagetosend'];


mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$mysqli = new mysqli("localhost", "root", "", "tstblog");

$query = "INSERT INTO blog VALUES ('','$messagetosend','$id_sender')" ; 
$mysqli->query($query);

$idblog=$mysqli->insert_id ;

echo"<h1> $idblog <h1>";
foreach($iduser as $k=>$v){ 


$query = "INSERT INTO `blogsender_recever`(`id_blogsender_recever`, `idsender`, `idrecever`, `idblog`) VALUES ('','$id_sender','$k','$idblog')" ; 
$mysqli->query($query);

}

printf("New record has ID %d.\n", $mysqli->insert_id);


?>
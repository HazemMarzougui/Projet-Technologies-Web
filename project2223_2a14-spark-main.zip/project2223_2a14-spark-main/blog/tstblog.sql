-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 16 nov. 2022 à 00:09
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `tstblog`
--

-- --------------------------------------------------------

--
-- Structure de la table `blog`
--

CREATE TABLE `blog` (
  `idblog` int(50) NOT NULL,
  `msg` varchar(256) NOT NULL,
  `idsender` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `blog`
--

INSERT INTO `blog` (`idblog`, `msg`, `idsender`) VALUES
(6, 'azed', '88'),
(7, 'test final', '88');

-- --------------------------------------------------------

--
-- Structure de la table `blogsender_recever`
--

CREATE TABLE `blogsender_recever` (
  `id_blogsender_recever` int(11) NOT NULL,
  `idsender` varchar(50) NOT NULL,
  `idrecever` int(11) NOT NULL,
  `idblog` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `blogsender_recever`
--

INSERT INTO `blogsender_recever` (`id_blogsender_recever`, `idsender`, `idrecever`, `idblog`) VALUES
(1, '88', 20, 6),
(2, '88', 30, 6),
(3, '88', 10, 7),
(4, '88', 20, 7),
(5, '88', 30, 7),
(6, '88', 40, 7),
(7, '88', 50, 7),
(8, '88', 60, 7),
(9, '88', 70, 7),
(10, '88', 80, 7),
(11, '88', 90, 7),
(12, '88', 100, 7);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`idblog`);

--
-- Index pour la table `blogsender_recever`
--
ALTER TABLE `blogsender_recever`
  ADD PRIMARY KEY (`id_blogsender_recever`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `blog`
--
ALTER TABLE `blog`
  MODIFY `idblog` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `blogsender_recever`
--
ALTER TABLE `blogsender_recever`
  MODIFY `id_blogsender_recever` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

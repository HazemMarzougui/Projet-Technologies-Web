<?php
	include '../Controller/ProduitsC.php';


	$produitC=new ProduitsC();
	$listeProduit=$produitC->AfficherProduit(); 
?>
<html>
	<head></head>
	<body>
	    <button><a href="AjouterProduit.php">Ajouter un Produit</a></button>
		<center><h1>Liste des produits</h1></center>
		<table border="1" align="center">
			<tr>
				<th>idProduit</th>
				<th>idUser</th>
				<th>NomP</th>
				<th>prix</th>
				<th>quantite</th>
				<th>img</th>
				<th>Modifier</th>
				<th>Supprimer</th>
			</tr>
			<?php
				foreach($listeProduit as $produits){
			?>
			<tr>
				<td><?php echo $produits['idProduit']; ?></td>
				<td><?php echo $produits['idUser']; ?></td>
				<td><?php echo $produits['NomP']; ?></td>
				<td><?php echo $produits['prix']; ?></td>
				<td><?php echo $produits['quantite']; ?></td>
				<td><?php echo $produits['img']; ?></td>
				<td>
					<form method="GET" action="ModifierProduit.php">
						<input type="submit" name="Modifier" value="Modifier">
						<input type="hidden" value=<?php echo $produits['idProduit']; ?> name="idProduit">
					</form>
				</td>
				<td>
					<a href="SupprimerProduit.php?idProduit=<?php echo $produits['idProduit']; ?>">Supprimer</a>
				</td>
			</tr>
			<?php
				}
			?>
		</table>
	</body>
</html>

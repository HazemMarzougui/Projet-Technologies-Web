<?php
	include '../Controller/ProduitsC.php';
	$produitC=new ProduitsC();
	$produitC->SupprimerProduit($_GET["idProduit"]);
	header('Location:AfficherProduit.php');
?>
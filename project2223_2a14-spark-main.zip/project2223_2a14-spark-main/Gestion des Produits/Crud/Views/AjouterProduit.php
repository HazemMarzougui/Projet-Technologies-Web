<?php
include_once '../Model/Produits.php';
include_once '../Controller/ProduitsC.php';



$error = "";

// create user
$produits = null;

// create an instance of the controller
$produitC = new ProduitsC();
if (
    isset($_POST["idUser"]) &&		
    isset($_POST["NomP"]) &&
    isset($_POST["prix"]) && 
    isset($_POST["quantite"]) && 
    isset($_POST["img"])
) {
    if (
        !empty($_POST['idUser']) &&
        !empty($_POST["NomP"]) && 
        !empty($_POST["prix"]) && 
        !empty($_POST["quantite"]) && 
        !empty($_POST["img"]) 
    ) {
        $produits = new Produit(
            $_POST['idUser'],
            $_POST['NomP'], 
            $_POST['prix'],
            $_POST['quantite'],
            $_POST['img'],
        );
        $produitC->AjouterProduit($produits);
        header('Location:AfficherProduit.php');
    }
    else
        $error = "Missing information";
}   


?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Display</title>
</head>
    <body>
        <button><a href="AfficherProduit.php">Retour a la liste des produits</a></button>
        <hr>
        
        <div id="error">
            <?php ?>
        </div>
        
        <form action="" method="POST">
            <table border="1" align="center">
				<tr>
                    <td>
                        <label for="idUser">id User:
                        </label>
                    </td>
                    <td><input type="text" name="idUser" id="idUser" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="NomP">Nom Produit:
                        </label>
                    </td>
                    <td><input type="text" name="NomP" id="NomP" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="prix">Prix:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="prix" id="prix">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="quantite"> Quantité:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="quantite" id="quantite">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="img">Image Produit:
                        </label>
                    </td>
                    <td>
                        <input type="img" name="img" id="img" >
                    </td>
                </tr>  
                
         
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Envoyer"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>

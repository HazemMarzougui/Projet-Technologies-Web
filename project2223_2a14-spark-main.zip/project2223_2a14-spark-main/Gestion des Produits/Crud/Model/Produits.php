<?php
	class Produit{
		private $idProduit=null;
		private $idUser=null;
		private $NomP=null;
		private $prix=null;
		private $quantite=null;
		private $img=null;
		function __construct($idUser, $NomP, $prix, $quantite, $img){
			$this->idUser=$idUser;
			$this->NomP=$NomP;
			$this->prix=$prix;
			$this->quantite=$quantite;
			$this->img=$img;
		}
		function getidProduit(){
			return $this->idProduit;
		}
		function getidUser(){
			return $this->idUser;
		}
		function getNomP(){
			return $this->NomP;
		}
		function getprix(){
			return $this->prix;
		}
		function getquantite(){
			return $this->quantite;
		}
		function getimg(){
			return $this->img;
		}
		function setidUser(int $idUser){
			$this->idUser=$idUser;
		}
		function setNomP(string $NomP){
			$this->NomP=$NomP;
		}
		function setprix(int $prix){
			$this->prix=$prix;
		}
		function setquantite(int $quantite){
			$this->quantite=$quantite;
		}
		function setimg(string $img){
			$this->img=$img;
		}

	}
	
?>